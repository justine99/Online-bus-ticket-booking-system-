
<div class="ui accordion">
  
  <div class="title" onclick="$('#c2').slideToggle();">
  
    <div class="title" onclick="$('#c4').slideToggle();">
    <i class="dropdown icon"></i>
    Who is the Developer of this system?
  </div>
  <div class="content" id="c4">
    <p class="transition">Good question, The developer is Justine Kifua</a> or Email me at: <a>justineraphael88@gmail.com</a> for more inquiries. </p>
  </div>
</div>