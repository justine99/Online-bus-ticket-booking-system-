<!DOCTYPE html>

<html lang="en">

  <head>

    <meta charset="UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link

      href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"

      rel="stylesheet"

    />

    <link rel="stylesheet" href="style.css" />

    <title>Home</title>

  </head>

  <body>
    <h1>KIFUA BUS SERVICES</h1>

    <nav>
        <a href="#">Home</a>
        <a href="info.php">Booking</a>
        <a href="routes.php">Routes</a>
        <a href="#">About</a>
        <a href="#">Contacts</a>
        <div class="animation start-home"></div>
    </nav>
    
    <p>
      By <span>UATECH</span>
    </p> 

  </body>

</html>