<!DOCTYPE html>

<html lang="en">

  <head>

    <meta charset="UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    <link

      href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap"

      rel="stylesheet"

    />

    <link rel="stylesheet" href="sty.css" />

    <title>Home</title>

  </head>

  <body>
    <h1>KIFUA BUS SERVICES</h1>

    <nav>
        <a href="index.php">Home</a>
      
        <div class="animation start-home"></div>
    </nav>
     
        <p>DAR TO MWANZA 6:00AM</p>
        <p>DAR TO MWANZA 10:00AM</p>
        <p>DAR TO ARUSHA 6:00AM</p>
        DAR TO ARUSHA 10:00AM
        DAR TO MBEYA 6:00AM
        DAR TO MBEYA 10:00AM
        DAR TO TANGA 6:00AM
        DAR TO TANGA 10:00AM


    </p>
    

  </body>

</html>